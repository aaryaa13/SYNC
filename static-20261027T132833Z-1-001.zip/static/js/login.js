// =========================================
// ELEMENTS
// =========================================

const loginForm = document.getElementById("loginForm");

const email = document.getElementById("email");
const password = document.getElementById("password");

const togglePassword = document.querySelector(".togglePassword");
const themeToggle = document.querySelector(".themeToggle");
const googleBtn = document.querySelector(".googleBtn");


// =========================================
// SHOW / HIDE PASSWORD
// =========================================

if (togglePassword) {

    togglePassword.addEventListener("click", () => {

        if (password.type === "password") {

            password.type = "text";

            togglePassword.classList.remove("fa-eye");
            togglePassword.classList.add("fa-eye-slash");

        } else {

            password.type = "password";

            togglePassword.classList.remove("fa-eye-slash");
            togglePassword.classList.add("fa-eye");

        }

    });

}


// =========================================
// DARK MODE
// =========================================

if (themeToggle) {

    themeToggle.addEventListener("click", () => {

        document.body.classList.toggle("dark");

    });

}


// =========================================
// LOGIN
// =========================================

if (loginForm) {

    loginForm.addEventListener("submit", async (e) => {

        e.preventDefault();

        const emailValue = email.value.trim();
        const passwordValue = password.value.trim();

        if (emailValue === "") {

            Swal.fire({
                icon: "warning",
                title: "Email Required",
                text: "Please enter your email."
            });

            return;

        }

        if (passwordValue === "") {

            Swal.fire({
                icon: "warning",
                title: "Password Required",
                text: "Please enter your password."
            });

            return;

        }

        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailPattern.test(emailValue)) {

            Swal.fire({
                icon: "warning",
                title: "Invalid Email",
                text: "Please enter a valid email."
            });

            return;

        }

        try {

            const response = await fetch("http://127.0.0.1:8000/api/login", {

                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({

                    email: emailValue,
                    password: passwordValue

                })

            });

            const result = await response.json();

            if (response.ok) {

                localStorage.setItem(
                    "user",
                    JSON.stringify(result)
                );

                Swal.fire({

    icon: "success",

    title: result.is_onboarded
        ? "Welcome Back 🌸"
        : "Welcome to SYNC 🌸",

    text: result.is_onboarded
        ? "Login Successful!"
        : "Let's set up your wellness profile.",

    timer: 1800,

    showConfirmButton: false

});

                setTimeout(() => {

                    if (result.is_onboarded) {

                        window.location.href = "/dashboard";

                    } else {

                        window.location.href = "/onboarding";

                    }

                }, 1800);

            } else {

                Swal.fire({

                    icon: "error",
                    title: "Login Failed",
                    text: result.detail || "Invalid Email or Password"

                });

            }

        } catch (error) {

            console.error(error);

            Swal.fire({

                icon: "error",
                title: "Server Error",
                text: "Unable to connect to the server."

            });

        }

    });

}


// =========================================
// GOOGLE LOGIN
// =========================================

if (googleBtn) {

    googleBtn.addEventListener("click", () => {

        Swal.fire({

            icon: "info",
            title: "Coming Soon",
            text: "Google Sign-In will be available soon."

        });

    });

}