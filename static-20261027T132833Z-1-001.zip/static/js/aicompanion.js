/* =========================================================
   SYNC - AI COMPANION
   PART 1
   SETUP + CHAT + GROQ AI + QUICK ACTIONS
========================================================= */

document.addEventListener("DOMContentLoaded", function () {

    /* =====================================================
       ELEMENTS
    ===================================================== */

    const openAIBtn = document.getElementById("aiCompanionBtn");
    const aiOverlay = document.getElementById("aiOverlay");

    const setupScreen = document.getElementById("companionSetupScreen");
    const chatScreen = document.getElementById("companionChatScreen");

    const companionInput = document.getElementById("companionName");
    const continueCompanion = document.getElementById("continueCompanion");

    const namePills = document.querySelectorAll(".name-pill");

    const closeSetup = document.getElementById("closeSetup");
    const closeAI = document.getElementById("closeAI");

    const botName = document.getElementById("botName");
    const typingName = document.getElementById("typingName");

    const chatContainer = document.getElementById("chatContainer");

    const userInput = document.getElementById("userInput");
    const sendButton = document.getElementById("sendMessage");

    const typingIndicator = document.getElementById("typingIndicator");

    const quickButtons = document.querySelectorAll(".quick-chip");


    /* =====================================================
       STATE
    ===================================================== */

    let companionName =
        localStorage.getItem("syncCompanionName") || "";

    let chatHistory = [];

    let aiRequestInProgress = false;


    /* =====================================================
       LOAD SAVED CHAT
    ===================================================== */

    try {

        const savedChat =
            localStorage.getItem("syncChat");

        if (savedChat) {

            chatHistory =
                JSON.parse(savedChat);

        }

        if (!Array.isArray(chatHistory)) {

            chatHistory = [];

        }

    } catch (error) {

        console.error(
            "Could not load chat history:",
            error
        );

        chatHistory = [];

    }


    /* =====================================================
       SAVE CHAT
    ===================================================== */

    function saveChat() {

        try {

            localStorage.setItem(
                "syncChat",
                JSON.stringify(chatHistory)
            );

        } catch (error) {

            console.error(
                "Could not save chat:",
                error
            );

        }

    }


    /* =====================================================
       UPDATE COMPANION NAME
    ===================================================== */

    function updateCompanionName(name) {

        companionName = name;

        if (botName) {

            botName.textContent = name;

        }

        if (typingName) {

            typingName.textContent = name;

        }

        if (userInput) {

            userInput.placeholder =
                `Ask ${name} anything...`;

        }

    }


    /* =====================================================
       SETUP SCREEN
    ===================================================== */

    function showSetupScreen() {

        if (!setupScreen || !chatScreen) {

            return;

        }

        chatScreen.classList.remove("active-screen");

        setupScreen.classList.add("active-screen");


        setTimeout(function () {

            if (companionInput) {

                companionInput.focus();

            }

        }, 200);

    }


    /* =====================================================
       CHAT SCREEN
    ===================================================== */

    function showChatScreen() {

        if (!setupScreen || !chatScreen) {

            return;

        }

        setupScreen.classList.remove("active-screen");

        chatScreen.classList.add("active-screen");

        updateCompanionName(
            companionName
        );

        loadChat();


        setTimeout(function () {

            if (userInput) {

                userInput.focus();

            }

        }, 200);

    }


    /* =====================================================
       OPEN COMPANION
    ===================================================== */

    function openCompanion() {

        if (!aiOverlay) {

            return;

        }

        companionName =
            localStorage.getItem(
                "syncCompanionName"
            ) || "";

        aiOverlay.classList.add("active");


        if (companionName) {

            showChatScreen();

        } else {

            showSetupScreen();

        }

    }


    /* =====================================================
       CLOSE COMPANION
    ===================================================== */

    function closeCompanion() {

        if (!aiOverlay) {

            return;

        }

        aiOverlay.classList.remove("active");

    }


    /* =====================================================
       OPEN BUTTON
    ===================================================== */

    if (openAIBtn) {

        openAIBtn.addEventListener(
            "click",
            function (event) {

                event.preventDefault();

                openCompanion();

            }
        );

    }


    /* =====================================================
       NAME SUGGESTIONS
    ===================================================== */

    namePills.forEach(function (pill) {

        pill.addEventListener(
            "click",
            function () {

                if (!companionInput) {

                    return;

                }

                const selectedName =
                    pill.textContent.trim();


                companionInput.value =
                    selectedName;


                companionInput.classList.remove(
                    "input-error"
                );


                namePills.forEach(
                    function (item) {

                        item.classList.remove(
                            "selected"
                        );

                    }
                );


                pill.classList.add(
                    "selected"
                );

            }
        );

    });


    /* =====================================================
       CREATE COMPANION
    ===================================================== */

    function createCompanion() {

        if (!companionInput) {

            return;

        }

        const name =
            companionInput.value.trim();


        if (!name) {

            companionInput.classList.add(
                "input-error"
            );

            companionInput.focus();

            return;

        }


        if (name.length > 20) {

            companionInput.classList.add(
                "input-error"
            );

            return;

        }


        localStorage.setItem(
            "syncCompanionName",
            name
        );


        updateCompanionName(name);


        chatHistory = [];

        saveChat();


        showChatScreen();

    }


    /* =====================================================
       CONTINUE BUTTON
    ===================================================== */

    if (continueCompanion) {

        continueCompanion.addEventListener(
            "click",
            createCompanion
        );

    }


    /* =====================================================
       COMPANION NAME INPUT
    ===================================================== */

    if (companionInput) {

        companionInput.addEventListener(
            "input",
            function () {

                companionInput.classList.remove(
                    "input-error"
                );


                namePills.forEach(
                    function (pill) {

                        pill.classList.remove(
                            "selected"
                        );

                    }
                );

            }
        );


        companionInput.addEventListener(
            "keydown",
            function (event) {

                if (event.key === "Enter") {

                    event.preventDefault();

                    createCompanion();

                }

            }
        );

    }


    /* =====================================================
       CLOSE BUTTONS
    ===================================================== */

    if (closeSetup) {

        closeSetup.addEventListener(
            "click",
            closeCompanion
        );

    }


    if (closeAI) {

        closeAI.addEventListener(
            "click",
            closeCompanion
        );

    }


    /* =====================================================
       CLICK OUTSIDE POPUP
    ===================================================== */

    if (aiOverlay) {

        aiOverlay.addEventListener(
            "click",
            function (event) {

                if (event.target === aiOverlay) {

                    closeCompanion();

                }

            }
        );

    }


    /* =====================================================
       ESCAPE KEY
    ===================================================== */

    document.addEventListener(
        "keydown",
        function (event) {

            if (event.key === "Escape") {

                closeCompanion();

            }

        }
    );


    /* =====================================================
       SAFE HTML
    ===================================================== */

    function escapeHTML(value) {

        const div =
            document.createElement("div");

        div.textContent =
            String(value);

        return div.innerHTML;

    }


    function formatBotMessage(message) {

        return escapeHTML(message)
            .replace(/\n/g, "<br>");

    }


    /* =====================================================
       SCROLL CHAT
    ===================================================== */

    function scrollChat() {

        if (!chatContainer) {

            return;

        }


        requestAnimationFrame(
            function () {

                chatContainer.scrollTop =
                    chatContainer.scrollHeight;

            }
        );

    }


    /* =====================================================
       ADD USER MESSAGE
    ===================================================== */

    function addUserMessage(
        message,
        save = true
    ) {

        if (!chatContainer) {

            return;

        }


        const row =
            document.createElement("div");

        row.className =
            "user-row";


        const messageBox =
            document.createElement("div");

        messageBox.className =
            "user-message";

        messageBox.textContent =
            message;


        row.appendChild(
            messageBox
        );


        chatContainer.appendChild(
            row
        );


        if (save) {

            chatHistory.push({

                sender: "user",

                message: message

            });


            saveChat();

        }


        scrollChat();

    }


    /* =====================================================
       ADD BOT MESSAGE
    ===================================================== */

    function addBotMessage(
        message,
        save = true
    ) {

        if (!chatContainer) {

            return;

        }


        const row =
            document.createElement("div");

        row.className =
            "bot-row";


        const avatar =
            document.createElement("div");

        avatar.className =
            "bot-avatar-small";


        const avatarImage =
            document.createElement("img");

        avatarImage.src =
            "/static/images/WCface.png";

        avatarImage.alt =
            "Wellness Companion";


        avatar.appendChild(
            avatarImage
        );


        const messageBox =
            document.createElement("div");

        messageBox.className =
            "bot-message";


        const title =
            document.createElement("h4");

        title.textContent =
            companionName ||
            "Wellness Companion";


        const paragraph =
            document.createElement("p");

        paragraph.innerHTML =
            formatBotMessage(message);


        messageBox.appendChild(
            title
        );

        messageBox.appendChild(
            paragraph
        );


        row.appendChild(
            avatar
        );

        row.appendChild(
            messageBox
        );


        chatContainer.appendChild(
            row
        );


        if (save) {

            chatHistory.push({

                sender: "bot",

                message: message

            });


            saveChat();

        }


        scrollChat();

    }


    /* =====================================================
       LOAD CHAT
    ===================================================== */

    function loadChat() {

        if (!chatContainer) {

            return;

        }


        chatContainer.innerHTML = "";


        if (chatHistory.length === 0) {

            const greeting =
`Hi! I'm ${companionName}. 💙

I'm your personal wellness companion.

You can ask me about periods, symptoms, PCOS/PCOD, pregnancy questions, vaginal health, home remedies, mood changes, nutrition, hydration and general wellness.

You can ask personal or uncomfortable questions here too.

How are you feeling today?`;


            addBotMessage(
                greeting,
                true
            );


            return;

        }


        chatHistory.forEach(
            function (chat) {

                if (
                    !chat ||
                    typeof chat.message !== "string"
                ) {

                    return;

                }


                if (chat.sender === "user") {

                    addUserMessage(
                        chat.message,
                        false
                    );

                } else {

                    addBotMessage(
                        chat.message,
                        false
                    );

                }

            }
        );


        scrollChat();

    }


    /* =====================================================
       TYPING INDICATOR
    ===================================================== */

    function showTyping() {

        if (!typingIndicator) {

            return;

        }


        typingIndicator.style.display =
            "flex";


        scrollChat();

    }


    function hideTyping() {

        if (!typingIndicator) {

            return;

        }


        typingIndicator.style.display =
            "none";

    }


    /* =====================================================
       BUSY STATE
    ===================================================== */

    function setChatBusy(isBusy) {

        aiRequestInProgress =
            isBusy;


        if (sendButton) {

            sendButton.disabled =
                isBusy;

        }


        if (userInput) {

            userInput.disabled =
                isBusy;

        }

    }


    /* =====================================================
       GROQ / FASTAPI CHAT REQUEST
    ===================================================== */

    async function askAI(
        message,
        historyForRequest
    ) {

        const response =
            await fetch(
                "http://127.0.0.1:8000/api/chat",
                {

                    method: "POST",

                    headers: {

                        "Content-Type":
                            "application/json",

                        "Accept":
                            "application/json"

                    },

                    body: JSON.stringify({

                        message: message,

                        companion_name:
                            companionName || "Bloom",

                        history:
                            historyForRequest

                    })

                }
            );


        let data = null;


        try {

            data =
                await response.json();

        } catch (error) {

            console.error(
                "Could not parse AI response:",
                error
            );

        }


        if (!response.ok) {

            const errorMessage =

                data && data.detail

                    ? data.detail

                    : `AI request failed (${response.status})`;


            throw new Error(
                errorMessage
            );

        }


        if (
            !data ||
            data.success !== true ||
            typeof data.reply !== "string"
        ) {

            throw new Error(
                "The AI returned an invalid response."
            );

        }


        return data.reply.trim();

    }


    /* =====================================================
       SEND MESSAGE
    ===================================================== */

    async function sendMessage() {

        if (!userInput) {

            return;

        }


        if (aiRequestInProgress) {

            return;

        }


        const message =
            userInput.value.trim();


        if (!message) {

            return;

        }


        const historyForRequest =

            chatHistory
                .slice(-12)
                .map(
                    function (chat) {

                        return {

                            sender:
                                chat.sender,

                            message:
                                chat.message

                        };

                    }
                );


        addUserMessage(
            message
        );


        userInput.value = "";


        showTyping();

        setChatBusy(true);


        try {

            const reply =
                await askAI(
                    message,
                    historyForRequest
                );


            hideTyping();


            addBotMessage(
                reply
            );

        } catch (error) {

            hideTyping();


            console.error(
                "AI Companion error:",
                error
            );


            addBotMessage(
`I'm having trouble connecting to my response service right now. 💙

Please try sending your message again in a moment.`
            );

        } finally {

            setChatBusy(false);


            if (userInput) {

                userInput.focus();

            }

        }

    }


    /* =====================================================
       SEND BUTTON
    ===================================================== */

    if (sendButton) {

        sendButton.addEventListener(
            "click",
            sendMessage
        );

    }


    /* =====================================================
       ENTER TO SEND
    ===================================================== */

    if (userInput) {

        userInput.addEventListener(
            "keydown",
            function (event) {

                if (
                    event.key === "Enter" &&
                    !event.shiftKey
                ) {

                    event.preventDefault();

                    sendMessage();

                }

            }
        );

    }


    /* =====================================================
       QUICK ACTION BUTTONS

       These functions are defined in the later parts:
       openHomeRemedies()
       showSymptomsMenu()
       findNearbyGynecologists()
       showWellnessTip()
    ===================================================== */

    quickButtons.forEach(
        function (button) {

            button.addEventListener(
                "click",
                function () {

                    const action =
                        button.dataset.action;


                    if (
                        action === "cramps" &&
                        typeof window.syncOpenHomeRemedies === "function"
                    ) {

                        window.syncOpenHomeRemedies();

                        return;

                    }


                    if (
                        action === "symptoms" &&
                        typeof window.syncShowSymptomsMenu === "function"
                    ) {

                        window.syncShowSymptomsMenu();

                        return;

                    }


                    if (
                        action === "doctor" &&
                        typeof window.syncFindNearbyGynecologists === "function"
                    ) {

                        window.syncFindNearbyGynecologists();

                        return;

                    }


                    if (
                        action === "tips" &&
                        typeof window.syncShowWellnessTip === "function"
                    ) {

                        window.syncShowWellnessTip();

                        return;

                    }

                }
            );

        }
    );


    /* =====================================================
       EXPOSE SHARED FUNCTIONS FOR PARTS 2 + 3
    ===================================================== */

    window.syncCompanion = {

        addUserMessage:
            addUserMessage,

        addBotMessage:
            addBotMessage,

        showTyping:
            showTyping,

        hideTyping:
            hideTyping,

        scrollChat:
            scrollChat,

        askAI:
            askAI,

        saveChat:
            saveChat,

        getChatHistory:
            function () {

                return chatHistory;

            },

        getCompanionName:
            function () {

                return companionName;

            },

        getChatContainer:
            function () {

                return chatContainer;

            }

    };

});
/* =========================================================
   SYNC - AI COMPANION
   PART 2
   HOME REMEDIES + SYMPTOM MENU
========================================================= */

document.addEventListener("DOMContentLoaded", function () {

    /* =====================================================
       GET SHARED FUNCTIONS FROM PART 1
    ===================================================== */

    const companion =
        window.syncCompanion;


    if (!companion) {

        console.error(
            "SYNC Companion Part 1 was not loaded."
        );

        return;

    }


    const addUserMessage =
        companion.addUserMessage;

    const addBotMessage =
        companion.addBotMessage;

    const showTyping =
        companion.showTyping;

    const hideTyping =
        companion.hideTyping;

    const scrollChat =
        companion.scrollChat;

    const askAI =
        companion.askAI;


    /* =====================================================
       ALL HOME REMEDIES

       These match the symptoms from your Log Period popup:
       Cramps
       Headache
       Back Pain
       Bloating
       Fatigue
       Acne
       Nausea
       Breast Tenderness
       Mood Swings
       Food Cravings
       Insomnia
       Constipation
       Diarrhea
       Dizziness
       Low Energy
       Stress
    ===================================================== */

    const homeRemedies = {

        /* ================= CRAMPS ================= */

        cramps: {

            label: "🩸 Cramps",

            name: "Cramps",

            response:
`For mild period cramps, you can try:

• Place a heating pad or warm water bottle on your lower abdomen.

• Take a warm shower or bath.

• Try gentle stretching or a short walk.

• Drink enough water.

• Rest if your body feels tired.

If your cramps are severe, suddenly much worse than usual, or regularly interfere with your daily activities, consider speaking with a healthcare professional.`

        },


        /* ================= HEADACHE ================= */

        headache: {

            label: "🤒 Headache",

            name: "Headache",

            response:
`For a mild headache, you can try:

• Drink some water.

• Eat something if you haven't eaten for several hours.

• Rest somewhere quiet and comfortable.

• Reduce screen brightness and take a screen break.

• Try a cool or warm compress, depending on what feels better.

• Make sure you're getting enough sleep.

Seek medical attention for a sudden extremely severe headache or a headache accompanied by fainting, confusion, weakness, major vision changes or other concerning symptoms.`

        },


        /* ================= BACK PAIN ================= */

        backPain: {

            label: "💢 Back Pain",

            name: "Back Pain",

            response:
`For mild period-related back pain, you can try:

• Apply a heating pad or warm water bottle to your lower back.

• Take a warm shower or bath.

• Try gentle lower-back stretches.

• Avoid sitting in exactly the same position for long periods.

• Take a short gentle walk if you're comfortable doing so.

• Rest in a position that supports your lower back.

If your back pain is severe, persistent or getting worse, consider speaking with a healthcare professional.`

        },


        /* ================= BLOATING ================= */

        bloating: {

            label: "💨 Bloating",

            name: "Bloating",

            response:
`For period-related bloating, you can try:

• Drink water regularly throughout the day.

• Reduce very salty foods temporarily.

• Eat smaller, regular meals if large meals make you uncomfortable.

• Try a gentle walk.

• Eat slowly.

• Notice whether particular foods consistently make your bloating worse.

If bloating becomes severe, persistent or frequently occurs outside your cycle, consider discussing it with a healthcare professional.`

        },


        /* ================= FATIGUE ================= */

        fatigue: {

            label: "😴 Fatigue",

            name: "Fatigue",

            response:
`If you're feeling fatigued around your period, you can try:

• Prioritize getting enough sleep.

• Drink enough fluids.

• Eat regular balanced meals.

• Include normal dietary sources of protein and iron.

• Try gentle movement if you feel comfortable.

• Give yourself short rest breaks instead of pushing through exhaustion.

If fatigue is severe or persistent, especially with very heavy bleeding, faintness or shortness of breath, consider speaking with a healthcare professional.`

        },


        /* ================= ACNE ================= */

        acne: {

            label: "🌼 Acne",

            name: "Acne",

            response:
`For mild cycle-related acne, you can try:

• Wash your face gently rather than scrubbing it.

• Avoid picking or squeezing spots.

• Use non-comedogenic skincare and makeup.

• Remove makeup before sleeping.

• Keep pillowcases and things that regularly touch your face clean.

• Keep your skincare routine simple if your skin feels irritated.

Persistent, painful or scarring acne may benefit from advice from a dermatologist or healthcare professional.`

        },


        /* ================= NAUSEA ================= */

        nausea: {

            label: "🤢 Nausea",

            name: "Nausea",

            response:
`For mild nausea, you can try:

• Take small, frequent sips of water.

• Eat smaller meals rather than one large meal.

• Choose simple foods that you tolerate well.

• Avoid smells or foods that make the nausea worse.

• Sit upright after eating.

• Rest somewhere comfortable.

If you're repeatedly vomiting, unable to keep fluids down, becoming dehydrated or experiencing severe abdominal pain, seek medical advice.`

        },


        /* ================= BREAST TENDERNESS ================= */

        breastTenderness: {

            label: "🤍 Breast Tenderness",

            name: "Breast Tenderness",

            response:
`For mild breast tenderness around your period, you can try:

• Wear a comfortable supportive bra.

• Try a warm or cool compress.

• Avoid clothing that puts uncomfortable pressure on your chest.

• Rest if certain activities make the tenderness worse.

• Keep track of whether the tenderness consistently follows your menstrual cycle.

A new persistent lump, unusual nipple discharge, skin changes or persistent one-sided pain should be evaluated by a healthcare professional.`

        },


        /* ================= MOOD SWINGS ================= */

        moodSwings: {

            label: "🎭 Mood Swings",

            name: "Mood Swings",

            response:
`For cycle-related mood changes, you can try:

• Get enough sleep.

• Eat regular meals.

• Take a gentle walk or spend some time outside.

• Write down what you're feeling.

• Give yourself short breaks when you're overwhelmed.

• Talk to someone you trust.

If mood changes become severe, persist outside your menstrual cycle or significantly interfere with your daily life, consider speaking with a healthcare professional.`

        },


        /* ================= FOOD CRAVINGS ================= */

        foodCravings: {

            label: "🍫 Food Cravings",

            name: "Food Cravings",

            response:
`Food cravings around your period can happen.

You can try:

• Eat regular meals instead of skipping them.

• Pair snacks with protein or fibre so they're more satisfying.

• Keep yourself hydrated.

• Enjoy the food you're craving in a reasonable amount.

• Notice whether your cravings become stronger when you're tired or haven't eaten enough.

You don't need to completely avoid foods you're craving — focus on keeping your overall eating pattern balanced.`

        },


        /* ================= INSOMNIA ================= */

        insomnia: {

            label: "🌙 Insomnia",

            name: "Insomnia",

            response:
`If you're having trouble sleeping, you can try:

• Keep approximately the same sleep and wake time each day.

• Reduce bright screens before bed.

• Keep your room comfortable, quiet and dark.

• Avoid consuming caffeine late in the day.

• Try gentle stretching or slow breathing before sleeping.

• Create a simple relaxing bedtime routine.

If insomnia continues for weeks or significantly affects your daily functioning, consider speaking with a healthcare professional.`

        },


        /* ================= CONSTIPATION ================= */

        constipation: {

            label: "🍬 Constipation",

            name: "Constipation",

            response:
`For mild constipation, you can try:

• Drink enough water throughout the day.

• Gradually include fibre-rich foods such as fruits, vegetables and whole grains.

• Try gentle walking or other light movement.

• Don't repeatedly ignore the urge to use the bathroom.

• Keep your meals regular.

Seek medical advice if constipation is persistent or accompanied by severe abdominal pain, vomiting or blood in your stool.`

        },


        /* ================= DIARRHEA ================= */

        diarrhea: {

            label: "💧 Diarrhea",

            name: "Diarrhea",

            response:
`For mild diarrhea, focus especially on hydration.

You can try:

• Take frequent small sips of water.

• Replace fluids regularly.

• Eat simple foods that you tolerate.

• Avoid foods that clearly make your symptoms worse.

• Rest.

Seek medical advice if diarrhea is severe or persistent, contains blood, causes significant abdominal pain or leads to signs of dehydration.`

        },


        /* ================= DIZZINESS ================= */

        dizziness: {

            label: "💫 Dizziness",

            name: "Dizziness",

            response:
`If you're mildly dizzy, you can try:

• Sit or lie down until the feeling passes.

• Stand up slowly instead of suddenly.

• Drink some water.

• Eat something if you haven't eaten for several hours.

• Rest somewhere cool and comfortable.

• Avoid driving or doing anything risky while you're dizzy.

If dizziness is severe, repeatedly returns, causes fainting or occurs with heavy bleeding, chest pain, breathing difficulty or neurological symptoms, seek medical attention.`

        },


        /* ================= LOW ENERGY ================= */

        lowEnergy: {

            label: "💤 Low Energy",

            name: "Low Energy",

            response:
`If you're experiencing low energy, you can try:

• Eat regular balanced meals.

• Drink enough fluids.

• Prioritize sleep.

• Take a short gentle walk if you feel up to it.

• Give yourself short rest breaks.

• Include normal dietary sources of protein and iron.

If your low energy is unusually severe or continues for a long time, consider discussing it with a healthcare professional.`

        },


        /* ================= STRESS ================= */

        stress: {

            label: "😣 Stress",

            name: "Stress",

            response:
`If you're feeling stressed, you can try:

• Take a few slow, comfortable breaths.

• Step away from your screen for a few minutes.

• Take a gentle walk.

• Write down what's worrying you.

• Break a large task into one small next step.

• Talk to someone you trust.

• Protect some time for sleep and rest.

If stress or anxiety is consistently interfering with your daily life, additional support from a healthcare or mental-health professional may help.`

        }

    };


    /* =====================================================
       CREATE SYMPTOM BUTTON MENU
    ===================================================== */

    function createSymptomButtonMenu(
        clickHandler
    ) {

        const chatContainer =
            companion.getChatContainer();


        if (!chatContainer) {

            return;

        }


        const row =
            document.createElement("div");


        row.className =
            "bot-row remedy-menu-row";


        const spacer =
            document.createElement("div");


        spacer.className =
            "bot-avatar-small remedy-avatar-spacer";


        const menu =
            document.createElement("div");


        menu.className =
            "remedy-symptom-menu";


        Object.entries(homeRemedies)
            .forEach(
                function ([key, symptom]) {

                    const button =
                        document.createElement(
                            "button"
                        );


                    button.type =
                        "button";


                    button.className =
                        "remedy-symptom-chip";


                    button.textContent =
                        symptom.label;


                    button.addEventListener(
                        "click",
                        function () {

                            clickHandler(key);

                            row.remove();

                        }
                    );


                    menu.appendChild(
                        button
                    );

                }
            );


        row.appendChild(
            spacer
        );


        row.appendChild(
            menu
        );


        chatContainer.appendChild(
            row
        );


        scrollChat();

    }


    /* =====================================================
       HOME REMEDIES QUICK ACTION
    ===================================================== */

    function openHomeRemedies() {

        addUserMessage(
            "🌼 Home Remedies"
        );


        addBotMessage(
            "Of course 💙 What would you like a home remedy for? Choose the symptom you're experiencing."
        );


        createSymptomButtonMenu(
            selectHomeRemedy
        );

    }


    /* =====================================================
       SELECT HOME REMEDY
    ===================================================== */

    function selectHomeRemedy(key) {

        const remedy =
            homeRemedies[key];


        if (!remedy) {

            return;

        }


        addUserMessage(
            remedy.label
        );


        showTyping();


        setTimeout(
            function () {

                hideTyping();


                addBotMessage(
                    remedy.response
                );

            },
            400
        );

    }


    /* =====================================================
       MY SYMPTOMS QUICK ACTION
    ===================================================== */

    function showSymptomsMenu() {

        addUserMessage(
            "🩸 My Symptoms"
        );


        addBotMessage(
`Tell me what you're experiencing today. 💙

You can choose one of your logged-period symptoms below, or type your symptoms in your own words.`
        );


        createSymptomButtonMenu(
            handleSymptomSelection
        );

    }


    /* =====================================================
       HANDLE SELECTED SYMPTOM WITH AI
    ===================================================== */

    async function handleSymptomSelection(key) {

        const symptom =
            homeRemedies[key];


        if (!symptom) {

            return;

        }


        const message =
            `I'm experiencing ${symptom.name}. What could help and when should I be concerned?`;


        /*
           Save history BEFORE adding the new message
           so the same user message isn't duplicated
           in the API context.
        */

        const history =
            companion.getChatHistory();


        const historyForRequest =
            history
                .slice(-12)
                .map(
                    function (chat) {

                        return {

                            sender:
                                chat.sender,

                            message:
                                chat.message

                        };

                    }
                );


        addUserMessage(
            `I'm experiencing ${symptom.name}.`
        );


        showTyping();


        try {

            const reply =
                await askAI(
                    message,
                    historyForRequest
                );


            hideTyping();


            addBotMessage(
                reply
            );

        } catch (error) {

            hideTyping();


            console.error(
                "Symptom AI error:",
                error
            );


            /*
               Groq failed, so use our built-in
               symptom guidance instead.
            */

            addBotMessage(
                symptom.response
            );

        }

    }


    /* =====================================================
       EXPOSE FUNCTIONS TO PART 1
    ===================================================== */

    window.syncOpenHomeRemedies =
        openHomeRemedies;


    window.syncShowSymptomsMenu =
        showSymptomsMenu;


    /* =====================================================
       OPTIONAL ACCESS FOR PART 3
    ===================================================== */

    window.syncHomeRemedies =
        homeRemedies;

});
/* =========================================================
   SYNC - AI COMPANION
   PART 3
   NEARBY GYNECOLOGISTS + WELLNESS TIPS
========================================================= */

document.addEventListener("DOMContentLoaded", function () {

    /* =====================================================
       GET SHARED FUNCTIONS FROM PART 1
    ===================================================== */

    const companion =
        window.syncCompanion;


    if (!companion) {

        console.error(
            "SYNC Companion Part 1 was not loaded."
        );

        return;

    }


    const addUserMessage =
        companion.addUserMessage;

    const addBotMessage =
        companion.addBotMessage;

    const showTyping =
        companion.showTyping;

    const hideTyping =
        companion.hideTyping;

    const scrollChat =
        companion.scrollChat;


    /* =====================================================
       SETTINGS
    ===================================================== */

    const NEARBY_API =
        "http://127.0.0.1:8000/api/nearby-gynecologists";

    const MAX_DOCTORS_TO_SHOW = 5;


    /* =====================================================
       GET USER LOCATION

       This runs ONLY after the user clicks
       "Nearby Gynecologist".
    ===================================================== */

    function getCurrentLocation() {

        return new Promise(
            function (resolve, reject) {

                if (!navigator.geolocation) {

                    reject(
                        new Error(
                            "Geolocation is not supported by this browser."
                        )
                    );

                    return;

                }


                navigator.geolocation.getCurrentPosition(

                    function (position) {

                        resolve({

                            latitude:
                                position.coords.latitude,

                            longitude:
                                position.coords.longitude

                        });

                    },


                    function (error) {

                        let message =
                            "I couldn't access your location.";


                        switch (error.code) {

                            case error.PERMISSION_DENIED:

                                message =
                                    "Location permission was denied.";

                                break;


                            case error.POSITION_UNAVAILABLE:

                                message =
                                    "Your current location could not be determined.";

                                break;


                            case error.TIMEOUT:

                                message =
                                    "Getting your location took too long.";

                                break;

                        }


                        reject(
                            new Error(message)
                        );

                    },


                    {

                        enableHighAccuracy: true,

                        timeout: 10000,

                        maximumAge: 60000

                    }

                );

            }
        );

    }


    /* =====================================================
       FETCH NEARBY GYNECOLOGISTS
    ===================================================== */

    async function fetchNearbyGynecologists(
        latitude,
        longitude
    ) {

        const url =
            `${NEARBY_API}?lat=${encodeURIComponent(latitude)}&lon=${encodeURIComponent(longitude)}`;


        const response =
            await fetch(
                url,
                {

                    method: "GET",

                    headers: {

                        "Accept":
                            "application/json"

                    }

                }
            );


        let data = null;


        try {

            data =
                await response.json();

        } catch (error) {

            console.error(
                "Could not parse nearby doctors response:",
                error
            );

        }


        if (!response.ok) {

            let errorMessage =
                `Doctor search failed (${response.status}).`;


            if (
                data &&
                typeof data.detail === "string"
            ) {

                errorMessage =
                    data.detail;

            }


            throw new Error(
                errorMessage
            );

        }


        if (!data) {

            throw new Error(
                "The doctor search returned no data."
            );

        }


        return data;

    }


    /* =====================================================
       DISTANCE CALCULATION

       Used if the backend result doesn't already
       contain a distance.
    ===================================================== */

    function calculateDistanceKm(
        lat1,
        lon1,
        lat2,
        lon2
    ) {

        const earthRadiusKm =
            6371;


        function toRadians(value) {

            return value * Math.PI / 180;

        }


        const deltaLat =
            toRadians(lat2 - lat1);

        const deltaLon =
            toRadians(lon2 - lon1);


        const firstLat =
            toRadians(lat1);

        const secondLat =
            toRadians(lat2);


        const a =

            Math.sin(deltaLat / 2) *
            Math.sin(deltaLat / 2) +

            Math.cos(firstLat) *
            Math.cos(secondLat) *

            Math.sin(deltaLon / 2) *
            Math.sin(deltaLon / 2);


        const c =
            2 *
            Math.atan2(
                Math.sqrt(a),
                Math.sqrt(1 - a)
            );


        return earthRadiusKm * c;

    }


    /* =====================================================
       NORMALIZE DOCTOR DATA
    ===================================================== */

    function prepareDoctors(
        doctors,
        userLatitude,
        userLongitude
    ) {

        if (!Array.isArray(doctors)) {

            return [];

        }


        return doctors
            .map(
                function (doctor) {

                    if (!doctor) {

                        return null;

                    }


                    const latitude =
                        Number(
                            doctor.latitude ??
                            doctor.lat
                        );


                    const longitude =
                        Number(
                            doctor.longitude ??
                            doctor.lon ??
                            doctor.lng
                        );


                    let distanceKm =
                        Number(
                            doctor.distance_km ??
                            doctor.distance
                        );


                    if (
                        !Number.isFinite(distanceKm) &&
                        Number.isFinite(latitude) &&
                        Number.isFinite(longitude)
                    ) {

                        distanceKm =
                            calculateDistanceKm(
                                userLatitude,
                                userLongitude,
                                latitude,
                                longitude
                            );

                    }


                    return {

                        name:
                            doctor.name ||
                            "Gynecology Clinic",

                        address:
                            doctor.address ||
                            "Address not available",

                        phone:
                            doctor.phone ||
                            null,

                        website:
                            doctor.website ||
                            null,

                        speciality:
                            doctor.speciality ||
                            doctor.specialty ||
                            "Gynecology",

                        latitude:
                            Number.isFinite(latitude)
                                ? latitude
                                : null,

                        longitude:
                            Number.isFinite(longitude)
                                ? longitude
                                : null,

                        distanceKm:
                            Number.isFinite(distanceKm)
                                ? distanceKm
                                : null

                    };

                }
            )
            .filter(Boolean)
            .filter(
                function (doctor) {

                    /*
                       We only want results within
                       the requested 10 km radius.
                    */

                    if (doctor.distanceKm === null) {

                        return true;

                    }


                    return doctor.distanceKm <= 10;

                }
            )
            .sort(
                function (a, b) {

                    if (
                        a.distanceKm === null &&
                        b.distanceKm === null
                    ) {

                        return 0;

                    }


                    if (a.distanceKm === null) {

                        return 1;

                    }


                    if (b.distanceKm === null) {

                        return -1;

                    }


                    return (
                        a.distanceKm -
                        b.distanceKm
                    );

                }
            );

    }


    /* =====================================================
       SAFE TEXT
    ===================================================== */

    function safeText(value) {

        if (
            value === null ||
            value === undefined
        ) {

            return "";

        }


        return String(value);

    }


    /* =====================================================
       CREATE GOOGLE MAPS LINK
    ===================================================== */

    function getDirectionsURL(doctor) {

        if (
            doctor.latitude !== null &&
            doctor.longitude !== null
        ) {

            return (
                "https://www.google.com/maps/search/?api=1&query=" +
                encodeURIComponent(
                    `${doctor.latitude},${doctor.longitude}`
                )
            );

        }


        return (
            "https://www.google.com/maps/search/?api=1&query=" +
            encodeURIComponent(
                `${doctor.name} ${doctor.address}`
            )
        );

    }


    /* =====================================================
       DISPLAY DOCTOR CARDS
    ===================================================== */

    function displayDoctors(
        doctors,
        totalCount
    ) {

        const chatContainer =
            companion.getChatContainer();


        if (!chatContainer) {

            return;

        }


        if (doctors.length === 0) {

            addBotMessage(
`I couldn't find a nearby gynecologist within 10 km from the available search results.

You can try again later, or search a slightly wider area if needed.`
            );

            return;

        }


        const numberToShow =
            Math.min(
                doctors.length,
                MAX_DOCTORS_TO_SHOW
            );


        addBotMessage(
`I found nearby gynecology options within about 10 km of your location. 💙

Here are the ${numberToShow} closest results I found:`
        );


        const resultsWrapper =
            document.createElement("div");


        resultsWrapper.className =
            "doctor-results-wrapper";


        doctors
            .slice(
                0,
                MAX_DOCTORS_TO_SHOW
            )
            .forEach(
                function (doctor, index) {

                    const card =
                        document.createElement("div");


                    card.className =
                        "doctor-result-card";


                    /* ================= NUMBER ================= */

                    const number =
                        document.createElement("div");


                    number.className =
                        "doctor-result-number";


                    number.textContent =
                        String(index + 1);


                    /* ================= INFO ================= */

                    const info =
                        document.createElement("div");


                    info.className =
                        "doctor-result-info";


                    /* ================= NAME ================= */

                    const name =
                        document.createElement("h4");


                    name.textContent =
                        safeText(
                            doctor.name
                        );


                    info.appendChild(
                        name
                    );


                    /* ================= DISTANCE ================= */

                    if (
                        doctor.distanceKm !== null
                    ) {

                        const distance =
                            document.createElement("p");


                        distance.className =
                            "doctor-distance";


                        distance.textContent =
                            `📍 ${doctor.distanceKm.toFixed(1)} km away`;


                        info.appendChild(
                            distance
                        );

                    }


                    /* ================= ADDRESS ================= */

                    const address =
                        document.createElement("p");


                    address.className =
                        "doctor-address";


                    address.textContent =
                        safeText(
                            doctor.address
                        );


                    info.appendChild(
                        address
                    );


                    /* ================= SPECIALITY ================= */

                    if (doctor.speciality) {

                        const speciality =
                            document.createElement("p");


                        speciality.className =
                            "doctor-speciality";


                        speciality.textContent =
                            `🩺 ${safeText(doctor.speciality)}`;


                        info.appendChild(
                            speciality
                        );

                    }


                    /* ================= ACTIONS ================= */

                    const actions =
                        document.createElement("div");


                    actions.className =
                        "doctor-card-actions";


                    /* ================= DIRECTIONS ================= */

                    const directions =
                        document.createElement("a");


                    directions.className =
                        "doctor-action-btn";


                    directions.textContent =
                        "📍 Directions";


                    directions.href =
                        getDirectionsURL(
                            doctor
                        );


                    directions.target =
                        "_blank";


                    directions.rel =
                        "noopener noreferrer";


                    actions.appendChild(
                        directions
                    );


                    /* ================= PHONE ================= */

                    if (doctor.phone) {

                        const phone =
                            document.createElement("a");


                        phone.className =
                            "doctor-action-btn";


                        phone.textContent =
                            "📞 Call";


                        const cleanPhone =
                            safeText(
                                doctor.phone
                            )
                            .replace(
                                /[^0-9+]/g,
                                ""
                            );


                        phone.href =
                            `tel:${cleanPhone}`;


                        actions.appendChild(
                            phone
                        );

                    }


                    /* ================= WEBSITE ================= */

                    if (
                        doctor.website &&
                        /^https?:\/\//i.test(
                            doctor.website
                        )
                    ) {

                        const website =
                            document.createElement("a");


                        website.className =
                            "doctor-action-btn";


                        website.textContent =
                            "🌐 Website";


                        website.href =
                            doctor.website;


                        website.target =
                            "_blank";


                        website.rel =
                            "noopener noreferrer";


                        actions.appendChild(
                            website
                        );

                    }


                    info.appendChild(
                        actions
                    );


                    card.appendChild(
                        number
                    );


                    card.appendChild(
                        info
                    );


                    resultsWrapper.appendChild(
                        card
                    );

                }
            );


        chatContainer.appendChild(
            resultsWrapper
        );


        if (
            totalCount >
            MAX_DOCTORS_TO_SHOW
        ) {

            const note =
                document.createElement("p");


            note.className =
                "doctor-results-note";


            note.textContent =
                `Showing the ${MAX_DOCTORS_TO_SHOW} closest results. ${totalCount} results were returned by the search service.`;


            resultsWrapper.appendChild(
                note
            );

        }


        scrollChat();

    }


    /* =====================================================
       FIND NEARBY GYNECOLOGISTS

       THIS IS THE FUNCTION CALLED BY THE QUICK ACTION.
    ===================================================== */

    async function findNearbyGynecologists() {

        addUserMessage(
            "🏥 Nearby Gynecologist"
        );


        addBotMessage(
`Sure 💙

I'll use your current location to look for gynecology options within 10 km.

Your browser may ask you to allow location access.`
        );


        showTyping();


        try {

            /* ================= GET LOCATION ================= */

            const location =
                await getCurrentLocation();


            /* ================= CALL BACKEND ================= */

            const data =
                await fetchNearbyGynecologists(
                    location.latitude,
                    location.longitude
                );


            hideTyping();


            /* ================= GET DOCTOR ARRAY ================= */

            let rawDoctors = [];


            if (
                Array.isArray(data.doctors)
            ) {

                rawDoctors =
                    data.doctors;

            } else if (
                Array.isArray(data.results)
            ) {

                rawDoctors =
                    data.results;

            } else if (
                Array.isArray(data)
            ) {

                rawDoctors =
                    data;

            }


            /* ================= PREPARE RESULTS ================= */

            const doctors =
                prepareDoctors(
                    rawDoctors,
                    location.latitude,
                    location.longitude
                );


            displayDoctors(
                doctors,
                doctors.length
            );

        } catch (error) {

            hideTyping();


            console.error(
                "Nearby gynecologist error:",
                error
            );


            let message =
`I couldn't complete the nearby gynecologist search right now. 💙

Please try again in a moment.`;


            if (
                error &&
                typeof error.message === "string"
            ) {

                const errorText =
                    error.message.toLowerCase();


                if (
                    errorText.includes(
                        "permission"
                    ) ||
                    errorText.includes(
                        "denied"
                    )
                ) {

                    message =
`I can't search nearby gynecologists without your location.

Please allow location access for this page in your browser, then press "Nearby Gynecologist" again.`;

                }


                else if (
                    errorText.includes(
                        "timeout"
                    ) ||
                    errorText.includes(
                        "took too long"
                    )
                ) {

                    message =
`Getting your location took too long.

Please check that location services are enabled and try again.`;

                }


                else if (
                    errorText.includes(
                        "unavailable"
                    ) ||
                    errorText.includes(
                        "determined"
                    )
                ) {

                    message =
`I couldn't determine your current location.

Please make sure location services are enabled, then try again.`;

                }

            }


            addBotMessage(
                message
            );

        }

    }


    /* =====================================================
       WELLNESS TIPS
    ===================================================== */

    const wellnessTips = [

        `Try to keep yourself hydrated throughout the day. Small, regular sips can be easier than suddenly drinking a lot of water.`,

        `Your energy can change throughout your menstrual cycle. On lower-energy days, adjusting your workload and getting enough rest can be more useful than forcing yourself through exhaustion.`,

        `Keeping a simple record of your period dates and symptoms can make patterns easier to notice over time.`,

        `Regular meals can help prevent the combination of hunger, low energy and headaches that can make an already uncomfortable day feel worse.`,

        `Gentle movement such as walking or stretching may help with mild cramps, bloating and stiffness if you feel comfortable doing it.`,

        `Sleep matters for more than energy. A consistent sleep routine can also support mood, concentration and general wellbeing.`,

        `If a menstrual symptom suddenly becomes much more severe than what is normal for you, don't assume you simply have to tolerate it. Consider discussing the change with a healthcare professional.`,

        `Your cycle doesn't need to be exactly the same every month. Tracking changes over several cycles gives you a much better picture than judging one unusual month by itself.`

    ];


    /* =====================================================
       SHOW WELLNESS TIP
    ===================================================== */

    function showWellnessTip() {

        addUserMessage(
            "✨ Wellness Tip"
        );


        const randomIndex =
            Math.floor(
                Math.random() *
                wellnessTips.length
            );


        const tip =
            wellnessTips[
                randomIndex
            ];


        showTyping();


        setTimeout(
            function () {

                hideTyping();


                addBotMessage(
`Here's a little wellness tip for today 🌸

${tip}`
                );

            },
            350
        );

    }


    /* =====================================================
       EXPOSE FUNCTIONS TO PART 1
    ===================================================== */

    window.syncFindNearbyGynecologists =
        findNearbyGynecologists;


    window.syncShowWellnessTip =
        showWellnessTip;

});
