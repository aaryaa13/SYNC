// =========================================
// ELEMENTS
// =========================================

const registerForm = document.getElementById("registerForm");

const fullname = document.getElementById("fullname");
const email = document.getElementById("email");
const password = document.getElementById("password");
const confirmPassword = document.getElementById("confirmPassword");

const strengthBar = document.querySelector(".strengthBar");
const strengthText = document.getElementById("strengthText");

const togglePassword = document.querySelector(".togglePassword");


// =========================================
// SHOW / HIDE PASSWORD
// =========================================

togglePassword.addEventListener("click", () => {

    if(password.type === "password"){

        password.type = "text";

        togglePassword.classList.remove("fa-eye");

        togglePassword.classList.add("fa-eye-slash");

    }

    else{

        password.type = "password";

        togglePassword.classList.remove("fa-eye-slash");

        togglePassword.classList.add("fa-eye");

    }

});


// =========================================
// PASSWORD STRENGTH
// =========================================

password.addEventListener("input", () => {

    let pass = password.value;

    let strength = 0;

    if(pass.length >= 8) strength++;

    if(/[A-Z]/.test(pass)) strength++;

    if(/[a-z]/.test(pass)) strength++;

    if(/[0-9]/.test(pass)) strength++;

    if(/[!@#$%^&*(),.?":{}|<>]/.test(pass)) strength++;

    switch(strength){

        case 0:
        case 1:

            strengthBar.style.width = "20%";
            strengthBar.style.background = "#FF6B81";

            strengthText.innerHTML = "Weak Password";

        break;

        case 2:
        case 3:

            strengthBar.style.width = "60%";
            strengthBar.style.background = "#FFC857";

            strengthText.innerHTML = "Medium Password";

        break;

        case 4:
        case 5:

            strengthBar.style.width = "100%";
            strengthBar.style.background = "#62D26F";

            strengthText.innerHTML = "Strong Password";

        break;

    }

});


// =========================================
// REGISTER
// =========================================

registerForm.addEventListener("submit", async (e)=>{

    e.preventDefault();

    const fullName = fullname.value.trim();

    const emailValue = email.value.trim();

    const passwordValue = password.value;

    const confirmValue = confirmPassword.value;

    // -------------------------

    if(fullName.length < 3){

        Swal.fire({

            icon:"warning",

            title:"Invalid Name",

            text:"Please enter your full name."

        });

        return;

    }

    // -------------------------

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if(!emailPattern.test(emailValue)){

        Swal.fire({

            icon:"warning",

            title:"Invalid Email",

            text:"Please enter a valid email."

        });

        return;

    }

    // -------------------------

    if(passwordValue.length < 8){

        Swal.fire({

            icon:"warning",

            title:"Weak Password",

            text:"Password should contain at least 8 characters."

        });

        return;

    }

    // -------------------------

    if(passwordValue !== confirmValue){

        Swal.fire({

            icon:"error",

            title:"Passwords don't match",

            text:"Please check your passwords."

        });

        return;

    }

    // =====================================
    // API
    // =====================================

    try{

        const response = await fetch("http://127.0.0.1:8000/api/register",{

            method:"POST",

            headers:{

                "Content-Type":"application/json"

            },

            body:JSON.stringify({

                name:fullName,

                email:emailValue,

                password:passwordValue

            })

        });

        const result = await response.json();

        if(response.ok){

            Swal.fire({

                icon:"success",

                title:"Welcome to SYNC 🌸",

                text:"Your account has been created successfully.",

                confirmButtonColor:"#9F6BFF"

            }).then(()=>{

                window.location.href="/Aisetup";

            });

        }

        else{

            Swal.fire({

                icon:"error",

                title:"Registration Failed",

                text:result.detail || result.message

            });

        }

    }

    catch(error){

        console.error(error);

        Swal.fire({

            icon:"error",

            title:"Server Error",

            text:"Could not connect to the backend."

        });

    }

});