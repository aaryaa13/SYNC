/* ==========================================
   SYNC Calendar
   PART 1
   Variables + Cycle Logic
========================================== */

// ==========================================
// Today's Date
// ==========================================
// ==========================================
// CURRENT USER
// ==========================================

const currentUser = JSON.parse(localStorage.getItem("user"));

if (!currentUser) {

    window.location.href = "/login";

}

const userKey = currentUser.email;
const today = new Date();
today.setHours(0, 0, 0, 0);

const oneDay = 1000 * 60 * 60 * 24;

let currentMonth = today.getMonth();
let currentYear = today.getFullYear();


// ==========================================
// Load User Profile
// ==========================================
let cycleData = JSON.parse(
    localStorage.getItem(`syncProfile_${userKey}`)
);

if (!cycleData) {

    window.location.href = "/onboarding";
    return;

}


// ==========================================
// Main Variables
// ==========================================

let lastPeriodDate = new Date(cycleData.lastPeriod);
lastPeriodDate.setHours(0, 0, 0, 0);

let cycleLength = Number(cycleData.cycleLength);
let periodLength = Number(
    cycleData.periodDuration || cycleData.periodLength
);

let nextPeriod = new Date(lastPeriodDate);

let cycleDay = 1;
let daysRemaining = 0;
let currentPhase = "";


// ==========================================
// Calendar Variables
// ==========================================

const monthNames = [

    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"

];

let selectedDate = null;


// ==========================================
// Day Records
// ==========================================

const dayRecords = JSON.parse(

    localStorage.getItem(`syncDayRecords_${userKey}`)

) || {};


// ==========================================
// Format Date
// ==========================================

function formatDate(date){

    return date.toLocaleDateString(

        "en-IN",

        {

            day: "numeric",
            month: "long",
            year: "numeric"

        }

    );

}


// ==========================================
// Days Between Dates
// ==========================================

function daysBetween(start, end){

    const first = new Date(start);
    const second = new Date(end);

    first.setHours(0,0,0,0);
    second.setHours(0,0,0,0);

    return Math.floor(

        (second - first) / oneDay

    );

}


// ==========================================
// Update Cycle Calculations
// ==========================================

function updateCycleData(){

    const passedDays = daysBetween(

        lastPeriodDate,
        today

    );

    cycleDay = (

        (

            passedDays % cycleLength

        )

        +

        cycleLength

    )

    %

    cycleLength

    + 1;


    // ======================================
    // Calculate NEXT Upcoming Period
    // ======================================

    nextPeriod = new Date(lastPeriodDate);

    while(nextPeriod <= today){

        nextPeriod.setDate(

            nextPeriod.getDate() + cycleLength

        );

    }


    daysRemaining = Math.max(

        daysBetween(today, nextPeriod),

        0

    );


    // ======================================
    // Current Phase
    // ======================================

    if(cycleDay <= periodLength){

        currentPhase = "🩸 Menstrual";

    }

    else if(cycleDay <= 13){

        currentPhase = "🌱 Follicular";

    }

    else if(cycleDay === 14){

        currentPhase = "💙 Ovulation";

    }

    else{

        currentPhase = "🌙 Luteal";

    }

    updateSummaryCards();

}


// ==========================================
// Update Summary Cards
// ==========================================

function updateSummaryCards(){

    document.getElementById("currentPhase").textContent =
    currentPhase;

    document.getElementById("cycleDay").textContent =
    `Day ${cycleDay}`;

    document.getElementById("nextPeriod").textContent =
    formatDate(nextPeriod);

    document.getElementById("daysRemaining").textContent =
    `${daysRemaining} Days`;

}


// ==========================================
// Cycle Day Helper
// ==========================================

function getCycleDay(date){

    const temp = new Date(date);

    temp.setHours(0,0,0,0);

    const diff = daysBetween(

        lastPeriodDate,
        temp

    );

    return (

        (

            diff % cycleLength

        )

        +

        cycleLength

    )

    %

    cycleLength

    + 1;

}


// ==========================================
// Logged Period
// ==========================================

function isLoggedPeriod(date){

    const check = new Date(date);

    check.setHours(0,0,0,0);

    const start = new Date(lastPeriodDate);

    start.setHours(0,0,0,0);

    const end = new Date(start);

    end.setDate(

        end.getDate()

        +

        periodLength

        -

        1

    );

    return (

        check >= start &&

        check <= end

    );

}


// ==========================================
// Predicted Period
// ==========================================

function isPredictedPeriod(date){

    const check = new Date(date);

    check.setHours(0,0,0,0);

    const start = new Date(nextPeriod);

    start.setHours(0,0,0,0);

    const end = new Date(start);

    end.setDate(

        end.getDate()

        +

        periodLength

        -

        1

    );

    return (

        check >= start &&

        check <= end

    );

}


// ==========================================
// Fertile Window
// ==========================================

function isFertileWindow(date){

    const day = getCycleDay(date);

    return (

        day >= 11 &&

        day <= 16

    );

}


// ==========================================
// Ovulation Day
// ==========================================

function isOvulationDay(date){

    return (

        getCycleDay(date) === 14

    );

}
/* ==========================================
   PART 2
   Calendar Rendering + Navigation
========================================== */

// ==========================================
// Render Calendar
// ==========================================

function renderCalendar(){

    document.getElementById("monthYear").textContent =
    `${monthNames[currentMonth]} ${currentYear}`;

    const calendarGrid =
    document.getElementById("calendarGrid");

    calendarGrid.innerHTML = "";

    const firstDay =
    new Date(currentYear, currentMonth, 1).getDay();

    const daysInMonth =
    new Date(currentYear, currentMonth + 1, 0).getDate();


    // ======================================
    // Empty Cells
    // ======================================

    for(let i = 0; i < firstDay; i++){

        const empty =
        document.createElement("div");

        empty.className =
        "calendar-day empty";

        calendarGrid.appendChild(empty);

    }


    // ======================================
    // Calendar Days
    // ======================================

    for(let day = 1; day <= daysInMonth; day++){

        const cell =
        document.createElement("div");

        cell.className =
        "calendar-day";

        cell.textContent = day;


        const cellDate =
        new Date(currentYear, currentMonth, day);

        cellDate.setHours(0,0,0,0);

        const dateKey =
        cellDate.toISOString().split("T")[0];


        // ==================================
        // TODAY
        // ==================================

        if(

            cellDate.getTime() === today.getTime()

        ){

            cell.classList.add("today");

        }


        // ==================================
        // PRIORITY
        // Logged
        // Predicted
        // Ovulation
        // Fertile
        // ==================================

        if(

            isLoggedPeriod(cellDate)

        ){

            cell.classList.add("logged");

        }

        else if(

            isPredictedPeriod(cellDate)

        ){

            cell.classList.add("predicted");

        }

        else if(

            isOvulationDay(cellDate)

        ){

            cell.classList.add("ovulation");

        }

        else if(

            isFertileWindow(cellDate)

        ){

            cell.classList.add("fertile");

        }


        // ==================================
        // Saved Entry Indicator
        // ==================================

        if(

            dayRecords[dateKey]

        ){

            cell.classList.add("has-entry");

        }


        // ==================================
        // Selected Day
        // ==================================

        if(

            selectedDate === dateKey

        ){

            cell.classList.add("selected");

        }


        // ==================================
        // Click Event
        // ==================================

        cell.addEventListener("click", () => {

            selectedDate = dateKey;

            renderCalendar();

            showSelectedRecord(dateKey);

        });

        calendarGrid.appendChild(cell);

    }

}


// ==========================================
// Refresh Calendar
// ==========================================

function refreshCalendar(){

    updateCycleData();

    renderCalendar();

    updateHistory();

    updatePredictions();

}


// ==========================================
// Previous Month
// ==========================================

document

.getElementById("prevMonth")

.addEventListener("click", () => {

    currentMonth--;

    if(currentMonth < 0){

        currentMonth = 11;

        currentYear--;

    }

    renderCalendar();

});


// ==========================================
// Next Month
// ==========================================

document

.getElementById("nextMonth")

.addEventListener("click", () => {

    currentMonth++;

    if(currentMonth > 11){

        currentMonth = 0;

        currentYear++;

    }

    renderCalendar();

});


// ==========================================
// Go To Current Month
// ==========================================

function goToCurrentMonth(){

    currentMonth =
    today.getMonth();

    currentYear =
    today.getFullYear();

    renderCalendar();

}


// ==========================================
// Calendar Legend
// ==========================================

const calendarLegend = {

    logged:
    "Logged Period",

    predicted:
    "Predicted Period",

    ovulation:
    "Ovulation",

    fertile:
    "Fertile Window"

};
/* ==========================================
   PART 3
   Modal + Flow + Symptoms
   Save Entry + History
========================================== */

// ==========================================
// Modal Elements
// ==========================================

const modal =
document.getElementById("logModal");

const openModalBtn =
document.getElementById("logPeriodBtn");

const closeModalBtn =
document.getElementById("closeModal");

const saveBtn =
document.getElementById("saveEntry");

const dateInput =
document.getElementById("startDate");

const notesInput =
document.getElementById("notes");

let selectedFlow = "";

let selectedSymptoms = [];


// ==========================================
// Open Modal
// ==========================================

openModalBtn.addEventListener("click", () => {

    modal.classList.add("show");

    const todayDate =
    new Date().toISOString().split("T")[0];

    dateInput.value = todayDate;

    dateInput.max = todayDate;

});


// ==========================================
// Close Modal
// ==========================================

closeModalBtn.addEventListener("click", closeModal);

window.addEventListener("click", (event) => {

    if(event.target === modal){

        closeModal();

    }

});

function closeModal(){

    modal.classList.remove("show");

    resetModal();

}


// ==========================================
// Flow Selection
// ==========================================

document

.querySelectorAll(".flow-pill")

.forEach(button => {

    button.addEventListener("click", () => {

        document

        .querySelectorAll(".flow-pill")

        .forEach(btn => {

            btn.classList.remove("active");

        });

        button.classList.add("active");

        selectedFlow =

        button.dataset.flow;

    });

});


// ==========================================
// Symptom Selection
// ==========================================

document

.querySelectorAll(".symptom-pill")

.forEach(button => {

    button.addEventListener("click", () => {

        button.classList.toggle("active");

        const symptom =
        button.dataset.symptom;

        if(selectedSymptoms.includes(symptom)){

            selectedSymptoms =

            selectedSymptoms.filter(

                item => item !== symptom

            );

        }

        else{

            selectedSymptoms.push(symptom);

        }

    });

});


// ==========================================
// Reset Modal
// ==========================================

function resetModal(){

    selectedFlow = "";

    selectedSymptoms = [];

    notesInput.value = "";

    document

    .querySelectorAll(".flow-pill")

    .forEach(btn => {

        btn.classList.remove("active");

    });

    document

    .querySelectorAll(".symptom-pill")

    .forEach(btn => {

        btn.classList.remove("active");

    });

}


// ==========================================
// Save Entry
// ==========================================

saveBtn.addEventListener("click", () => {

    if(!dateInput.value){

        alert("Please select a date.");

        return;

    }

    const selectedDateObj =
    new Date(dateInput.value);

    selectedDateObj.setHours(0,0,0,0);

    if(selectedDateObj > today){

        alert("Future dates cannot be logged.");

        return;

    }

    const dateKey = dateInput.value;


    // ======================================
    // Save Profile
    // ======================================

    cycleData.lastPeriod = dateKey;

    cycleData.cycleLength = cycleLength;

    cycleData.periodLength = periodLength;

    localStorage.setItem(

    `syncProfile_${userKey}`,

    JSON.stringify(cycleData)

);

    lastPeriodDate =
    new Date(dateKey);

    lastPeriodDate.setHours(0,0,0,0);


    // ======================================
    // Save Record
    // ======================================

    dayRecords[dateKey] = {

        flow:

            selectedFlow ||

            "Not Specified",

        symptoms:

            [...selectedSymptoms],

        notes:

            notesInput.value.trim()

    };

    localStorage.setItem(

    `syncDayRecords_${userKey}`,

    JSON.stringify(dayRecords)

);


    // ======================================
    // Refresh UI
    // ======================================

    selectedDate = dateKey;

    closeModal();

    refreshCalendar();

    showSelectedRecord(dateKey);

});


// ==========================================
// History
// ==========================================

function updateHistory(){

    const historyList =

    document.getElementById("historyList");

    historyList.innerHTML = "";

    const dates =

    Object.keys(dayRecords)

    .sort()

    .reverse();

    if(!dates.length){

        historyList.innerHTML =

        "<p>No records yet.</p>";

        return;

    }

    dates.slice(0,5).forEach(date => {

        const record =

        dayRecords[date];

        historyList.innerHTML += `

        <div class="history-item">

            <h4>${formatDate(new Date(date))}</h4>

            <p>

                <strong>Flow:</strong>

                ${record.flow}

            </p>

            <p>

                <strong>Symptoms:</strong>

                ${record.symptoms.length

                    ? record.symptoms.join(", ")

                    : "None"}

            </p>

        </div>

        `;

    });

}


// ==========================================
// Selected Day Record
// ==========================================

function showSelectedRecord(dateKey){

    const container =

    document.getElementById(

        "selectedDayRecord"

    );

    const record =

    dayRecords[dateKey];

    if(!record){

        container.innerHTML = `

        <p class="empty-record">

            No record found.

        </p>

        `;

        return;

    }

    container.innerHTML = `

    <div class="record-item">

        <div class="record-label">

            Date

        </div>

        <div class="record-value">

            ${formatDate(new Date(dateKey))}

        </div>

    </div>

    <div class="record-item">

        <div class="record-label">

            Flow

        </div>

        <div class="record-value">

            ${record.flow}

        </div>

    </div>

    <div class="record-item">

        <div class="record-label">

            Symptoms

        </div>

        <div class="record-value">

            ${record.symptoms.length

                ? record.symptoms.join(", ")

                : "None"}

        </div>

    </div>

    <div class="record-item">

        <div class="record-label">

            Notes

        </div>

        <div class="record-notes">

            ${record.notes || "No notes added."}

        </div>

    </div>

    `;

}
/* ==========================================
   PART 4
   Predictions + Profile + Initialization
========================================== */


// ==========================================
// Update Prediction Cards
// ==========================================

function updatePredictions(){
    const predictionList = document.getElementById("predictionList");

    // Calculate end date for next period
    const nextPeriodEnd = new Date(nextPeriod);
    nextPeriodEnd.setDate(nextPeriodEnd.getDate() + periodLength - 1);

    const ovulation = new Date(nextPeriod);
    ovulation.setDate(ovulation.getDate() - 14);

    const fertileStart = new Date(ovulation);
    fertileStart.setDate(fertileStart.getDate() - 5);

    const fertileEnd = new Date(ovulation);
    fertileEnd.setDate(fertileEnd.getDate() + 1);

    predictionList.innerHTML = `
        <div class="prediction-item">
            <h4>Next Period</h4>
            <p>${formatDate(nextPeriod)} - ${formatDate(nextPeriodEnd)}</p>
        </div>
        <div class="prediction-item">
            <h4>Ovulation</h4>
            <p>${formatDate(ovulation)}</p>
        </div>
        <div class="prediction-item">
            <h4>Fertile Window</h4>
            <p>${formatDate(fertileStart)} - ${formatDate(fertileEnd)}</p>
        </div>
    `;
}

// ==========================================
// Edit Cycle Button
// ==========================================

const editCycleBtn =
document.getElementById("editCycleBtn");

if(editCycleBtn){

    editCycleBtn.addEventListener("click", () => {

        alert(

            "Cycle editing feature will be available soon."

        );

    });

}


// ==========================================
// Save Profile
// ==========================================

function saveProfile(){

    cycleData = {

        lastPeriod:
            lastPeriodDate
            .toISOString()
            .split("T")[0],

        cycleLength:
            cycleLength,

        periodLength:
            periodLength

    };

    localStorage.setItem(

        `syncProfile_${userKey}`,

        JSON.stringify(cycleData)

    );

}


// ==========================================
// Refresh Dashboard
// ==========================================

function refreshDashboard(){

    updateCycleData();

    renderCalendar();

    updateHistory();

    updatePredictions();

}


// ==========================================
// Initialize Calendar
// ==========================================

function initializeCalendar(){

    updateCycleData();

    renderCalendar();

    updateHistory();

    updatePredictions();

}


// ==========================================
// Start Application
// ==========================================

document.addEventListener(

    "DOMContentLoaded",

    () => {

        initializeCalendar();

    }

);