// ==========================================
// SYNC ONBOARDING
// PART 1
// Step Navigation & Validation
// ==========================================


// ==========================================
// ELEMENTS
// ==========================================

const step1 = document.getElementById("step1");
const step2 = document.getElementById("step2");

const nextBtn = document.getElementById("nextBtn");
const backBtn = document.getElementById("backBtn");

const progressFill = document.getElementById("progressFill");
const stepText = document.getElementById("stepText");


// Step 1 Inputs

const age = document.getElementById("age");
const height = document.getElementById("height");
const weight = document.getElementById("weight");


// ==========================================
// VALIDATE STEP 1
// ==========================================

function validateStepOne() {

    let valid = true;

    const fields = [age, height, weight];

    fields.forEach(field => {

        field.classList.remove("input-error");

        if (field.value.trim() === "") {

            field.classList.add("input-error");

            valid = false;

        }

    });

    // Age validation

    if (age.value < 10 || age.value > 60) {

        age.classList.add("input-error");

        valid = false;

    }

    // Height validation

    if (height.value < 80 || height.value > 250) {

        height.classList.add("input-error");

        valid = false;

    }

    // Weight validation

    if (weight.value < 20 || weight.value > 250) {

        weight.classList.add("input-error");

        valid = false;

    }

    return valid;

}


// ==========================================
// NEXT BUTTON
// ==========================================

if (nextBtn) {

    nextBtn.addEventListener("click", () => {

        if (!validateStepOne()) {

            alert("Please complete all fields correctly.");

            return;

        }

        step1.classList.remove("active");

        step2.classList.add("active");

        progressFill.style.width = "100%";

        stepText.textContent = "Step 2 of 2";

        window.scrollTo({

            top: 0,

            behavior: "smooth"

        });

    });

}


// ==========================================
// BACK BUTTON
// ==========================================

if (backBtn) {

    backBtn.addEventListener("click", () => {

        step2.classList.remove("active");

        step1.classList.add("active");

        progressFill.style.width = "50%";

        stepText.textContent = "Step 1 of 2";

        window.scrollTo({

            top: 0,

            behavior: "smooth"

        });

    });

}


// ==========================================
// REMOVE ERROR ON INPUT
// ==========================================

const inputs = document.querySelectorAll("input, select");

inputs.forEach(input => {

    input.addEventListener("input", () => {

        input.classList.remove("input-error");

    });

});


// ==========================================
// PAGE LOADED
// ==========================================

document.addEventListener("DOMContentLoaded", () => {

    progressFill.style.width = "50%";

    step1.classList.add("active");

    console.log("🌸 Step Navigation Loaded");

});
// ==========================================
// SYNC ONBOARDING
// PART 2
// Live Prediction
// ==========================================


// ==========================================
// ELEMENTS
// ==========================================

const lastPeriod =
document.getElementById("lastPeriod");

const cycleLength =
document.getElementById("cycleLength");

const periodDuration =
document.getElementById("periodDuration");

const predictionCard =
document.querySelector(".prediction-card");

const nextPrediction =
document.getElementById("nextPrediction");

const phasePrediction =
document.getElementById("phasePrediction");


// ==========================================
// UPDATE PREDICTION
// ==========================================

function updatePrediction(){

    if(
        !lastPeriod.value ||
        !cycleLength.value ||
        !periodDuration.value
    ){

        predictionCard.classList.remove("show");

        return;

    }

    predictionCard.classList.add("show");


    const lastDate = new Date(lastPeriod.value);

    const cycle = parseInt(cycleLength.value);

    const duration = parseInt(periodDuration.value);


    // Calculate Next Period

    const nextDate = new Date(lastDate);

    nextDate.setDate(
        nextDate.getDate() + cycle
    );

    nextPrediction.textContent =
        nextDate.toLocaleDateString(
            "en-IN",
            {

                day:"numeric",

                month:"long",

                year:"numeric"

            }
        );


    // ======================================
    // Current Cycle Day
    // ======================================

    const today = new Date();

    const diffTime =
        today - lastDate;

    const cycleDay =
        Math.floor(
            diffTime /
            (1000 * 60 * 60 * 24)
        ) + 1;


    // ======================================
    // Phase Detection
    // ======================================

    let phase = "";

    if(cycleDay <= duration){

        phase = "🩸 Menstrual";

    }

    else if(cycleDay <= cycle / 2){

        phase = "🌱 Follicular";

    }

    else if(

        cycleDay >=
        Math.floor(cycle/2)

        &&

        cycleDay <=
        Math.floor(cycle/2)+2

    ){

        phase = "🥚 Ovulation";

    }

    else{

        phase = "🌙 Luteal";

    }


    phasePrediction.textContent =
        phase;

}


// ==========================================
// LIVE EVENTS
// ==========================================

lastPeriod.addEventListener(
    "change",
    updatePrediction
);

cycleLength.addEventListener(
    "change",
    updatePrediction
);

periodDuration.addEventListener(
    "change",
    updatePrediction
);


// ==========================================
// INITIAL CHECK
// ==========================================

updatePrediction();


console.log(
    "🌸 Prediction System Loaded"
);
// ==========================================
// SYNC ONBOARDING
// PART 3
// Save User Details
// ==========================================


// ==========================================
// ELEMENTS
// ==========================================

const finishBtn =
document.getElementById("finishBtn");


// ==========================================
// SAVE DATA
// ==========================================
// ==========================================
// SAVE DATA TO MYSQL
// ==========================================

async function saveUserProfile() {

    const currentUser = JSON.parse(localStorage.getItem("user"));

    if (!currentUser) {

        alert("Session expired. Please login again.");
        window.location.href = "/login";
        return false;

    }

    try {

        const response = await fetch("http://127.0.0.1:8000/api/onboarding", {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({

                email: currentUser.email,

                age: parseInt(age.value),

                height: parseInt(height.value),

                weight: parseInt(weight.value),

                last_period: lastPeriod.value,

                cycle_length: parseInt(cycleLength.value),

                period_duration: parseInt(periodDuration.value),

                next_period: nextPrediction.textContent,

                current_phase: phasePrediction.textContent

            })

        });

        const result = await response.json();

        if (!response.ok) {

            alert(result.detail || "Failed to save profile.");
            return false;

        }

        console.log("🌸 Profile saved to MySQL");

        return true;

    } catch (error) {

        console.error(error);

        alert("Unable to connect to server.");

        return false;

    }

}
// ==========================================
// LOADING BUTTON
// ==========================================

function startLoading(){

    finishBtn.classList.add("loading");

    finishBtn.disabled = true;

    finishBtn.innerHTML = "Creating Dashboard";

}

function stopLoading(){

    finishBtn.classList.remove("loading");

    finishBtn.disabled = false;

    finishBtn.innerHTML = `
        Continue
        <i class="fa-solid fa-arrow-right"></i>
    `;

}


// ==========================================
// FINISH BUTTON
// ==========================================

if (finishBtn) {

    finishBtn.addEventListener("click", async () => {

        // Validate Step 2
        if (
            lastPeriod.value === "" ||
            cycleLength.value === "" ||
            periodDuration.value === ""
        ) {

            alert("Please complete your cycle details.");
            return;

        }

        startLoading();

        const saved = await saveUserProfile();

        stopLoading();

        if (saved) {

    const currentUser = JSON.parse(
        localStorage.getItem("user")
    );

    if (currentUser) {

        currentUser.is_onboarded = true;

        localStorage.setItem(
            "user",
            JSON.stringify(currentUser)
        );

    }

    window.location.href = "/dashboard";

}

    });

}


