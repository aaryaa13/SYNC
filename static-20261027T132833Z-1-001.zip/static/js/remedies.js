/*==========================================================
        HOME REMEDIES DATABASE
==========================================================*/

const remedies = {

    cramps: [

        "Apply a heating pad for 15-20 minutes.",

        "Drink warm water.",

        "Try gentle stretching.",

        "Take a short walk.",

        "Avoid excessive caffeine."

    ],

    headache: [

        "Stay hydrated.",

        "Rest in a dark room.",

        "Avoid skipping meals.",

        "Reduce screen time."

    ],

    nausea: [

        "Drink ginger tea.",

        "Eat light meals.",

        "Avoid spicy food.",

        "Sip water slowly."

    ],

    bloating: [

        "Reduce salty food.",

        "Drink more water.",

        "Walk for 20 minutes.",

        "Eat smaller meals."

    ],

    fatigue: [

        "Sleep 7-9 hours.",

        "Eat iron-rich foods.",

        "Stay hydrated.",

        "Include protein in meals."

    ]

};


/*==========================================================
        SHOW REMEDIES
==========================================================*/

function getRemedy(type){

    if(!remedies[type]){

        return null;

    }

    let text = "✨ Here are a few things you can try:\n\n";

    remedies[type].forEach(item=>{

        text += "• " + item + "\n";

    });

    return text;

}


/*==========================================================
        NEAREST DOCTOR PLACEHOLDER
==========================================================*/

function getNearestDoctor(){

    return `🏥 You can use the "Nearby Gynecologists" section in SYNC to find hospitals and clinics near your location.`;

}


/*==========================================================
        CHATBOT HELPERS
==========================================================*/

function contains(text,words){

    return words.some(word=>

        text.includes(word)

    );

}


/*==========================================================
        SMART REPLY
==========================================================*/

function smartReply(text){

    let answer=[];

    if(

        contains(

            text,

            [

                "cramp",

                "pain"

            ]

        )

    ){

        answer.push(

            getRemedy("cramps")

        );

    }

    if(

        contains(

            text,

            [

                "headache",

                "migraine"

            ]

        )

    ){

        answer.push(

            getRemedy("headache")

        );

    }

    if(

        contains(

            text,

            [

                "fatigue",

                "weak",

                "tired"

            ]

        )

    ){

        answer.push(

            getRemedy("fatigue")

        );

    }

    if(

        contains(

            text,

            [

                "nausea",

                "vomit"

            ]

        )

    ){

        answer.push(

            getRemedy("nausea")

        );

    }

    if(

        contains(

            text,

            [

                "bloating",

                "bloated"

            ]

        )

    ){

        answer.push(

            getRemedy("bloating")

        );

    }

    if(

        contains(

            text,

            [

                "doctor",

                "hospital",

                "gynecologist"

            ]

        )

    ){

        answer.push(

            getNearestDoctor()

        );

    }

    if(answer.length===0){

        return null;

    }

    return answer.join("\n\n");

}