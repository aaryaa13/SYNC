/*==========================================================
                DOCTORS.JS
==========================================================*/

/*=========================
    GET USER LOCATION
==========================*/

function getUserLocation() {

    if (!navigator.geolocation) {

        return Promise.reject(
            "Geolocation is not supported by your browser."
        );

    }

    return new Promise((resolve, reject) => {

        navigator.geolocation.getCurrentPosition(

            position => {

                resolve({

                    latitude: position.coords.latitude,

                    longitude: position.coords.longitude

                });

            },

            error => {

                reject(error.message);

            }

        );

    });

}


/*=========================
    GOOGLE MAPS SEARCH
==========================*/

function openNearbyGynecologists() {

    getUserLocation()

        .then(location => {

            const latitude = location.latitude;

            const longitude = location.longitude;

            const url =
                `https://www.google.com/maps/search/gynecologist/@${latitude},${longitude},15z`;

            window.open(url, "_blank");

        })

        .catch(error => {

            alert(
                "Unable to access your location.\n\nPlease allow location permission and try again."
            );

            console.error(error);

        });

}


/*=========================
    CHATBOT FUNCTION
==========================*/

function getNearestDoctor() {

    openNearbyGynecologists();

    return `
🏥 I'm opening nearby gynecologists in Google Maps for you.

If your symptoms are severe or you're experiencing heavy bleeding, severe pain, fainting, or difficulty breathing, please seek medical attention immediately.
`;

}