// =========================================
// SYNC DASHBOARD
// PART 1
// USER • PROFILE • GREETING • CALENDAR
// =========================================


// =========================================
// CURRENT USER
// =========================================

const currentUser = JSON.parse(localStorage.getItem("user"));

if (!currentUser) {

    window.location.href = "/login";

}

const userKey = currentUser.email;

let profile = null;


// =========================================
// LOAD PROFILE
// =========================================

async function loadProfile() {

    try {

        const response = await fetch(

            `/api/profile/${encodeURIComponent(userKey)}`

        );

        if (!response.ok) {

            console.log("No profile found.");

            return;

        }

        profile = await response.json();

        updateGreeting();

        updateCycleDashboard();

        renderMiniCalendar();

    }

    catch (err) {

        console.error(err);

    }

}


// =========================================
// GREETING
// =========================================

function updateGreeting() {

    const greetingElement =
        document.getElementById("greeting");

    const welcomeTitle =
        document.getElementById("welcomeTitle");

    if (!greetingElement) return;

    const hour = new Date().getHours();

    let greeting = "";

    if (hour < 12) {

        greeting = "Good Morning ☀️";

    }

    else if (hour < 17) {

        greeting = "Good Afternoon 🌼";

    }

    else if (hour < 21) {

        greeting = "Good Evening 🌅";

    }

    else {

        greeting = "Good Night 🌙";

    }

    greetingElement.innerHTML =

        `${greeting}, <span>${currentUser.name}</span>`;

    if (welcomeTitle) {

        if (currentUser.firstLogin) {

            welcomeTitle.textContent =
                "Welcome to SYNC 🌸";

        }

        else {

            welcomeTitle.textContent =
                "Welcome Back ✨";

        }

    }

}


// =========================================
// TODAY DATE
// =========================================

const todayDate =
document.getElementById("todayDate");

if (todayDate) {

    todayDate.textContent =

        new Date().toLocaleDateString(

            "en-IN",

            {

                weekday: "long",

                day: "numeric",

                month: "long",

                year: "numeric"

            }

        );

}



// =========================================
// UPDATE CYCLE CARD
// =========================================

function updateCycleDashboard() {

    if (!profile) return;

    const lastPeriod =

        new Date(profile.last_period);

    const cycleLength =

        Number(profile.cycle_length);

    const periodDuration =

        Number(profile.period_duration);

    const today = new Date();

    const difference =

        Math.floor(

            (today - lastPeriod)

            /

            86400000

        );

    const cycleDay =

        (difference % cycleLength)

        + 1;

    let phase = "";

    if (cycleDay <= periodDuration)

        phase = "🩸 Menstrual";

    else if (cycleDay <= 13)

        phase = "🌱 Follicular";

    else if (cycleDay <= 16)

        phase = "🥚 Ovulation";

    else

        phase = "🌙 Luteal";

    document.getElementById("currentPhase").textContent =
        phase;

    document.getElementById("cycleDay").textContent =
        `Day ${cycleDay}`;

    const nextPeriod =
        new Date(lastPeriod);

    while (nextPeriod <= today) {

        nextPeriod.setDate(

            nextPeriod.getDate()

            +

            cycleLength

        );

    }

    document.getElementById("nextCycleDate").textContent =

        nextPeriod.toLocaleDateString(

            "en-IN",

            {

                day: "numeric",

                month: "long"

            }

        );

    const remaining =

        Math.ceil(

            (nextPeriod - today)

            /

            86400000

        );

    document.getElementById("daysRemaining").textContent =

        `${remaining} Days`;

    const status =
        document.getElementById("cycleStatus");

    if (cycleDay <= periodDuration)

        status.textContent = "On Period";

    else if (remaining <= 3)

        status.textContent = "Upcoming";

    else

        status.textContent = "Healthy";

}



// =========================================
// MINI CALENDAR
// =========================================

function renderMiniCalendar() {

    const calendarGrid =
        document.getElementById("calendarGrid");

    const calendarMonth =
        document.getElementById("calendarMonth");

    if (!calendarGrid) return;

    calendarGrid.innerHTML = "";

    const today = new Date();

    const month = today.getMonth();

    const year = today.getFullYear();

    const monthNames = [

        "January",

        "February",

        "March",

        "April",

        "May",

        "June",

        "July",

        "August",

        "September",

        "October",

        "November",

        "December"

    ];

    calendarMonth.textContent =

        `${monthNames[month]} ${year}`;

    const firstDay =

        new Date(year, month, 1).getDay();

    const totalDays =

        new Date(

            year,

            month + 1,

            0

        ).getDate();

    for (

        let i = 0;

        i < firstDay;

        i++

    ) {

        calendarGrid.appendChild(

            document.createElement("div")

        );

    }

    let periodStart = null;

    if (profile) {

        periodStart =

            new Date(

                profile.last_period

            ).getDate();

    }

    for (

        let day = 1;

        day <= totalDays;

        day++

    ) {

        const cell =

            document.createElement("div");

        cell.textContent = day;

        if (day === today.getDate())

            cell.classList.add("today");

        if (

            periodStart &&

            day === periodStart

        )

            cell.classList.add("period");

        calendarGrid.appendChild(cell);

    }

}
// =========================================
// PART 2A
// MOOD SYSTEM
// =========================================

// Elements

const moodModal =
document.getElementById("moodModal");

const openMoodPopup =
document.getElementById("openMoodPopup");

const selectedMoodEmoji =
document.getElementById("selectedMoodEmoji");

const selectedMoodText =
document.getElementById("selectedMoodText");

const moodOptions =
document.querySelectorAll(".mood-option");


// =========================================
// STORAGE
// =========================================

const moodStorageKey =
`selectedMood_${userKey}`;


// =========================================
// LOAD SAVED MOOD
// =========================================

loadMood();

function loadMood(){

    const savedMood = JSON.parse(

        localStorage.getItem(

            moodStorageKey

        )

    );

    if(!savedMood) return;

    if(selectedMoodEmoji){

        selectedMoodEmoji.textContent =

            savedMood.emoji;

    }

    if(selectedMoodText){

        selectedMoodText.textContent =

            savedMood.mood;

    }

    if(openMoodPopup){

        openMoodPopup.textContent =

            "Change Mood";

    }

}


// =========================================
// OPEN POPUP
// =========================================

if(openMoodPopup){

    openMoodPopup.addEventListener(

        "click",

        ()=>{

            moodModal.classList.add("show");

        }

    );

}


// =========================================
// CLOSE POPUP
// =========================================

if(moodModal){

    moodModal.addEventListener(

        "click",

        (e)=>{

            if(e.target===moodModal){

                moodModal.classList.remove(

                    "show"

                );

            }

        }

    );

}


// =========================================
// SELECT MOOD
// =========================================

moodOptions.forEach(option=>{

    option.addEventListener(

        "click",

        ()=>{

            const emoji =

                option.dataset.emoji;

            const mood =

                option.dataset.mood;

            if(selectedMoodEmoji){

                selectedMoodEmoji.textContent =

                    emoji;

            }

            if(selectedMoodText){

                selectedMoodText.textContent =

                    mood;

            }

            if(openMoodPopup){

                openMoodPopup.textContent =

                    "Change Mood";

            }

            localStorage.setItem(

                moodStorageKey,

                JSON.stringify({

                    emoji,

                    mood

                })

            );

            moodModal.classList.remove(

                "show"

            );

        }

    );

});


// =========================================
// RESET MOOD
// =========================================

function resetMood(){

    localStorage.removeItem(

        moodStorageKey

    );

    if(selectedMoodEmoji){

        selectedMoodEmoji.textContent =

            "😊";

    }

    if(selectedMoodText){

        selectedMoodText.textContent =

            "How are you feeling today?";

    }

    if(openMoodPopup){

        openMoodPopup.textContent =

            "Select Mood";

    }

}

console.log("✅ Mood System Loaded");
// =========================================
// PART 2B
// TO-DO SYSTEM
// =========================================

// Elements

const taskInput =
document.getElementById("taskInput");

const saveTask =
document.getElementById("saveTask");

const todoList =
document.getElementById("todoList");

const emptyTodo =
document.getElementById("emptyTodo");


// =========================================
// STORAGE
// =========================================

const taskStorageKey =
`tasks_${userKey}`;

let tasks = JSON.parse(

    localStorage.getItem(

        taskStorageKey

    )

) || [];


// =========================================
// INITIAL LOAD
// =========================================

renderTasks();


// =========================================
// BUTTON
// =========================================

if(saveTask){

    saveTask.addEventListener(

        "click",

        addTask

    );

}


// =========================================
// ENTER KEY
// =========================================

if(taskInput){

    taskInput.addEventListener(

        "keydown",

        e=>{

            if(e.key==="Enter"){

                addTask();

            }

        }

    );

}


// =========================================
// ADD TASK
// =========================================

function addTask(){

    if(!taskInput) return;

    const text =

        taskInput.value.trim();

    if(text==="") return;

    tasks.push({

        id:Date.now(),

        text:text,

        completed:false

    });

    taskInput.value="";

    saveTasks();

    renderTasks();

}


// =========================================
// SAVE
// =========================================

function saveTasks(){

    localStorage.setItem(

        taskStorageKey,

        JSON.stringify(tasks)

    );

}


// =========================================
// TOGGLE
// =========================================

function toggleTask(id){

    tasks = tasks.map(task=>{

        if(task.id===id){

            task.completed =

                !task.completed;

        }

        return task;

    });

    saveTasks();

    renderTasks();

}


// =========================================
// DELETE
// =========================================

function deleteTask(id){

    tasks = tasks.filter(

        task=>task.id!==id

    );

    saveTasks();

    renderTasks();

}


// =========================================
// RENDER
// =========================================

function renderTasks(){

    if(!todoList) return;

    todoList.innerHTML="";

    if(tasks.length===0){

        if(emptyTodo){

            emptyTodo.style.display="block";

        }

        return;

    }

    if(emptyTodo){

        emptyTodo.style.display="none";

    }

    tasks.forEach(task=>{

        const li =

            document.createElement("li");

        li.innerHTML=`

            <div class="task-left">

                <input
                    type="checkbox"
                    ${task.completed?"checked":""}>

                <span class="${task.completed?"completed":""}">

                    ${task.text}

                </span>

            </div>

            <button class="delete-btn">

                <i class="fa-solid fa-trash"></i>

            </button>

        `;

        li.querySelector("input")

        .addEventListener(

            "change",

            ()=>{

                toggleTask(task.id);

            }

        );

        li.querySelector(".delete-btn")

        .addEventListener(

            "click",

            ()=>{

                deleteTask(task.id);

            }

        );

        todoList.appendChild(li);

    });

}


// =========================================
// CLEAR
// =========================================

function clearAllTasks(){

    tasks=[];

    saveTasks();

    renderTasks();

}

console.log("✅ Todo System Loaded");
// =========================================
// PART 2C
// WATER • SLEEP • LOGOUT • INITIALIZATION
// =========================================

// =========================================
// STORAGE KEYS
// =========================================

const sleepStorageKey =
`sleepHours_${userKey}`;

const waterStorageKey =
`waterIntake_${userKey}`;



// =========================================
// WATER TRACKER
// =========================================

const waterCount =
document.getElementById("waterCount");

const addWater =
document.getElementById("addWater");

let waterIntake =

Number(

    localStorage.getItem(

        waterStorageKey

    )

) || 0;

updateWater();

function updateWater(){

    if(waterCount){

        waterCount.textContent =

            waterIntake;

    }

}

if(addWater){

    addWater.addEventListener(

        "click",

        ()=>{

            if(waterIntake<8){

                waterIntake++;

            }

            localStorage.setItem(

                waterStorageKey,

                waterIntake

            );

            updateWater();

        }

    );

}



// =========================================
// SLEEP TRACKER
// =========================================

const sleepInput =
document.getElementById("sleepHours");

const saveSleep =
document.getElementById("saveSleep");

if(sleepInput){

    sleepInput.value =

        localStorage.getItem(

            sleepStorageKey

        ) || "";

}

if(saveSleep){

    saveSleep.addEventListener(

        "click",

        ()=>{

            const value =

                sleepInput.value.trim();

            if(value===""){

                alert(

                    "Enter your sleep hours."

                );

                return;

            }

            if(

                Number(value)<0 ||

                Number(value)>24

            ){

                alert(

                    "Sleep hours must be between 0 and 24."

                );

                return;

            }

            localStorage.setItem(

                sleepStorageKey,

                value

            );

            saveSleep.textContent =

                "Saved ✓";

            setTimeout(()=>{

                saveSleep.textContent =

                "Save";

            },1500);

        }

    );

}



// =========================================
// NOTIFICATIONS
// =========================================

const notificationBtn =
document.getElementById("notificationBtn");

if(notificationBtn){

    notificationBtn.onclick=()=>{

        alert(

            "🎉 You're all caught up!"

        );

    };

}



// =========================================
// PROFILE
// =========================================

const profileBtn =
document.getElementById("profileBtn");

if(profileBtn){

    profileBtn.onclick=()=>{

        alert(

            `👤 ${currentUser.name}`

        );

    };

}



// =========================================
// LOGOUT
// =========================================

const logoutBtn =
document.getElementById("logoutBtn");

if(logoutBtn){

    logoutBtn.onclick=()=>{

        if(

            confirm(

                "Logout from SYNC?"

            )

        ){

            localStorage.removeItem(

                "user"

            );

            window.location.href="/login";

        }

    };

}



// =========================================
// CALENDAR BUTTONS
// =========================================

const prevMonth =
document.getElementById("prevMonth");

const nextMonth =
document.getElementById("nextMonth");

if(prevMonth){

    prevMonth.onclick=()=>{

        window.location.href="/calendar";

    };

}

if(nextMonth){

    nextMonth.onclick=()=>{

        window.location.href="/calendar";

    };

}



// =========================================
// WELCOME ANIMATION
// =========================================

const welcomeCard =
document.querySelector(

    ".welcome-card"

);

if(welcomeCard){

    welcomeCard.style.opacity="0";

    setTimeout(()=>{

        welcomeCard.style.transition=

        ".7s";

        welcomeCard.style.opacity="1";

    },200);

}



// =========================================
// CARD HOVER
// =========================================

document

.querySelectorAll(".card")

.forEach(card=>{

    card.addEventListener(

        "mouseenter",

        ()=>{

            card.style.transform=

            "translateY(-6px)";

        }

    );

    card.addEventListener(

        "mouseleave",

        ()=>{

            card.style.transform=

            "translateY(0px)";

        }

    );

});



// =========================================
// DASHBOARD READY
// =========================================

async function loadDashboard(){

    console.log(

        "🌸 Dashboard Ready"

    );

}



// =========================================
// DOM READY
// =========================================

document.addEventListener(

    "DOMContentLoaded",

    async ()=>{

        console.log(

            "🌸 SYNC Dashboard Loaded"

        );

        await loadProfile();

        await loadDashboard();

    }

);
// =========================================
// PART 2C
// WATER • SLEEP • LOGOUT • INITIALIZATION
// =========================================

// =========================================
// STORAGE KEYS
// =========================================

const sleepStorageKey =
`sleepHours_${userKey}`;

const waterStorageKey =
`waterIntake_${userKey}`;



// =========================================
// WATER TRACKER
// =========================================

const waterCount =
document.getElementById("waterCount");

const addWater =
document.getElementById("addWater");

let waterIntake =

Number(

    localStorage.getItem(

        waterStorageKey

    )

) || 0;

updateWater();

function updateWater(){

    if(waterCount){

        waterCount.textContent =

            waterIntake;

    }

}

if(addWater){

    addWater.addEventListener(

        "click",

        ()=>{

            if(waterIntake<8){

                waterIntake++;

            }

            localStorage.setItem(

                waterStorageKey,

                waterIntake

            );

            updateWater();

        }

    );

}



// =========================================
// SLEEP TRACKER
// =========================================

const sleepInput =
document.getElementById("sleepHours");

const saveSleep =
document.getElementById("saveSleep");

if(sleepInput){

    sleepInput.value =

        localStorage.getItem(

            sleepStorageKey

        ) || "";

}

if(saveSleep){

    saveSleep.addEventListener(

        "click",

        ()=>{

            const value =

                sleepInput.value.trim();

            if(value===""){

                alert(

                    "Enter your sleep hours."

                );

                return;

            }

            if(

                Number(value)<0 ||

                Number(value)>24

            ){

                alert(

                    "Sleep hours must be between 0 and 24."

                );

                return;

            }

            localStorage.setItem(

                sleepStorageKey,

                value

            );

            saveSleep.textContent =

                "Saved ✓";

            setTimeout(()=>{

                saveSleep.textContent =

                "Save";

            },1500);

        }

    );

}



// =========================================
// NOTIFICATIONS
// =========================================

const notificationBtn =
document.getElementById("notificationBtn");

if(notificationBtn){

    notificationBtn.onclick=()=>{

        alert(

            "🎉 You're all caught up!"

        );

    };

}



// =========================================
// PROFILE
// =========================================

const profileBtn =
document.getElementById("profileBtn");

if(profileBtn){

    profileBtn.onclick=()=>{

        alert(

            `👤 ${currentUser.name}`

        );

    };

}



// =========================================
// LOGOUT
// =========================================

const logoutBtn =
document.getElementById("logoutBtn");

if(logoutBtn){

    logoutBtn.onclick=()=>{

        if(

            confirm(

                "Logout from SYNC?"

            )

        ){

            localStorage.removeItem(

                "user"

            );

            window.location.href="/login";

        }

    };

}



// =========================================
// CALENDAR BUTTONS
// =========================================

const prevMonth =
document.getElementById("prevMonth");

const nextMonth =
document.getElementById("nextMonth");

if(prevMonth){

    prevMonth.onclick=()=>{

        window.location.href="/calendar";

    };

}

if(nextMonth){

    nextMonth.onclick=()=>{

        window.location.href="/calendar";

    };

}



// =========================================
// WELCOME ANIMATION
// =========================================

const welcomeCard =
document.querySelector(

    ".welcome-card"

);

if(welcomeCard){

    welcomeCard.style.opacity="0";

    setTimeout(()=>{

        welcomeCard.style.transition=

        ".7s";

        welcomeCard.style.opacity="1";

    },200);

}



// =========================================
// CARD HOVER
// =========================================

document

.querySelectorAll(".card")

.forEach(card=>{

    card.addEventListener(

        "mouseenter",

        ()=>{

            card.style.transform=

            "translateY(-6px)";

        }

    );

    card.addEventListener(

        "mouseleave",

        ()=>{

            card.style.transform=

            "translateY(0px)";

        }

    );

});



// =========================================
// DASHBOARD READY
// =========================================

async function loadDashboard(){

    console.log(

        "🌸 Dashboard Ready"

    );

}



// =========================================
// DOM READY
// =========================================

document.addEventListener(

    "DOMContentLoaded",

    async ()=>{

        console.log(

            "🌸 SYNC Dashboard Loaded"

        );

        await loadProfile();

        await loadDashboard();

    }

);
